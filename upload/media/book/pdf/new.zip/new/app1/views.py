from django.shortcuts import render
from django.http import HttpResponse

def home(request):
    return render(request,'home.html',{'name':"safeer",'age':21})


def index(request):
    return render(request,'index.html')

def about(request):
    return HttpResponse("About")