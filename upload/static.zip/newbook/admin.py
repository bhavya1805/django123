from django.contrib import admin
from newbook.models import Book
admin.site.register(Book)
